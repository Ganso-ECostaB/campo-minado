// Configurações do jogo.
let rows = 10;
let cols = 10;
let totalMines = 15;
let cells = [];
let flags = 0;
let revealedCells = 0;
let gameOver = false;
let timer;
let seconds = 0;
let gameWon = false;

// Referências de elementos do HTML.
const gameBoard = document.getElementById('game-board');
const timerDisplay = document.getElementById('timer');
const restartButton = document.getElementById('restart')
const advanceButton = document.getElementById('advance')

// Função para criar o tabuleiro.
function createBoard() {
  gameBoard.innerHTML = '';
  cells = [];
  flags = 0;
  revealedCells = 0;
  gameOver = false;
  seconds = 0;
  timerDisplay.textContent = seconds;


  // Inicializar as células.
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      const cell = document.createElement('div');
      cell.classList.add('cell');
      cell.dataset.row = i;
      cell.dataset.col = j;
      cell.addEventListener('click', revealCell);
      cell.addEventListener('contextmenu', placeFlag);
      gameBoard.appendChild(cell);
      cells.push({ element: cell, row: i, col: j, isMine: false, revealed: false, flag: false, adjacentMines: 0 });
    }
  }

  // Colocar as minas.
  let minesPlaced = 0;
  while (minesPlaced < totalMines) {
    const randomIndex = Math.floor(Math.random() * cells.length);
    const cell = cells[randomIndex];

    if (!cell.isMine) {
      cell.isMine = true;
      minesPlaced++;
    }
  }

  // Calcular números adjacentes às minas.
  for (let cell of cells) {
    if (!cell.isMine) {
      const neighbors = getNeighbors(cell);
      cell.adjacentMines = neighbors.filter(neighbor => neighbor.isMine).length;
    }
  }

  // Iniciar o timer do jogo.
  if (timer) clearInterval(timer);
  timer = setInterval(() => {
    if (!gameOver) {
      seconds++;
      timerDisplay.textContent = seconds;
    }
  }, 1000);
}

// Função para obter os vizinhos das células.
function getNeighbors(cell) {
  const neighbors = [];
  const directions = [
    [-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [1, 1], [-1, 1], [1, -1]
  ];

  for (let [dx, dy] of directions) {
    const neighbor = cells.find(c => c.row === cell.row + dx && c.col === cell.col + dy);
    if (neighbor) neighbors.push(neighbor);
  }

  return neighbors;
}

// Função para revelar células no tabuleiro.
function revealCell(event) {
  if (gameOver || event.target.classList.contains('flag')) return;

  const cell = cells.find(c => c.element === event.target);

  if (cell.revealed) return;

  cell.revealed = true;
  cell.element.classList.add('revealed');
 
  if (cell.isMine) {
    cell.element.classList.add('mine');
    gameOver = true;
    clearInterval(timer);
    alert('Game Over!');
    restartButton.style.display = "inline"
  } else {
    revealedCells++;
    if (cell.adjacentMines === 0) {
      // Revelar células adjacentes vazias
      const neighbors = getNeighbors(cell);
      for (let neighbor of neighbors) {
        if (!neighbor.revealed && !neighbor.isMine) {
          revealCell({ target: neighbor.element });
        }
      }
    }
    if (revealedCells === (cells.length - totalMines)) {
      gameWon = true;
      clearInterval(timer);
      alert('Você ganhou!');
      advanceButton.style.display = 'inline'
    }
    if (cell.adjacentMines > 0) {
      cell.element.textContent = cell.adjacentMines;
      if(cell.element.textContent === '1'){
        cell.element.style.color = 'blue'
      } else if(cell.element.textContent === '2'){
        cell.element.style.color = 'green'
      } else if(cell.element.textContent === '3'){
        cell.element.style.color = 'red'
      } else if(cell.element.textContent === '4'){
        cell.element.style.color = 'purple'
      } else if(cell.element.textContent === '5'){
        cell.element.style.color = 'yellow'
      } else if(cell.element.textContent === '6'){
        cell.element.style.color = 'cyan'
      } else if(cell.element.textContent === '7'){
        cell.element.style.color = 'gold'
      } else if(cell.element.textContent === '8'){
        cell.element.style.color = 'pink'
      } // Checa o número no quadrado para colocar a sua cor respectiva.
    }
  }
}

// Função para colocar bandeiras nas células.
function placeFlag(event) {
  event.preventDefault();
  if (gameOver) return;

  const cell = cells.find(c => c.element === event.target);
  if (cell.revealed) return;

  if (cell.flag) {
    cell.flag = false;
    flags--;
    cell.element.classList.remove('flag');
    cell.element.innerText = ''
  } else {
    if (flags < totalMines) {
      cell.flag = true;
      flags++;
      cell.element.classList.add('flag');
      cell.element.innerText = "X"
    }
  }
}

restartButton.addEventListener('click', function(){
  window.location.reload() // Reinicia o jogo.
})

advanceButton.addEventListener('click', function(){
  window.location.reload()
})

// Inicializar o jogo.
createBoard();


// Feito for Nicolas Ribeiro, Eduardo da Costa Belem e Valentina